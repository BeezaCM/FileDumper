package adris.altoclef.mixins;

import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(MinecraftClient.class)
public class SimpleOptionMixin {


    /**
     * this is used post 1.18 to change the gamma...
     * this is a placeholder class used in prior versions
     */

}
