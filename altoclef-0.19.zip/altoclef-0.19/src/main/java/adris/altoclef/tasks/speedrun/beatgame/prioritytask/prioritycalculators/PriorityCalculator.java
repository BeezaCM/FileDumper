package adris.altoclef.tasks.speedrun.beatgame.prioritytask.prioritycalculators;

public interface PriorityCalculator {

    double getPriority();

}
