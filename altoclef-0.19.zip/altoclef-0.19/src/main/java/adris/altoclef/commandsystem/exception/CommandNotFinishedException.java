package adris.altoclef.commandsystem.exception;

public class CommandNotFinishedException extends CommandException {

    public CommandNotFinishedException(String message) {
        super(message);
    }

}
