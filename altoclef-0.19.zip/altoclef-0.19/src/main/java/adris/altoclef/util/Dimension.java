package adris.altoclef.util;

public enum Dimension {
    OVERWORLD,
    NETHER,
    END
}
