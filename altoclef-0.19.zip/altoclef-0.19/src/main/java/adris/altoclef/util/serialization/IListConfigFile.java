package adris.altoclef.util.serialization;

public interface IListConfigFile {
    void onLoadStart();

    void addLine(String line);
}
