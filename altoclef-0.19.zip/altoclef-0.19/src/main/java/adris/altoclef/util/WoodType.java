package adris.altoclef.util;

public enum WoodType {
    ACACIA,
    BIRCH,
    CRIMSON,
    DARK_OAK,
    OAK,
    JUNGLE,
    SPRUCE,
    WARPED,
    MANGROVE,
    BAMBOO,
    CHERRY
}
