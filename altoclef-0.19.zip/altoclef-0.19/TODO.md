# TODO

### Misc
- Implement configs.
- Allow any bed color when crafting beds from wool.
- Add cherry blossom wood as a valid wood type or something? It doesn't seem to work properly atm.
- Maybe add some sort of system that finds and uses seed of the current world?


### Common death causes
- Improve escaping from lava.
- Prevent from looking endermen in the eyes.
- Do not hit pigmen in the nether (or implement a special behaviour when do).
- Maybe avoid bastions somehow?
