---
name: Minor Bug report
about: Report a bug that TEMPORARILY interrupts the bot and/or wastes time, but does NOT permanently stop the bot/require human input to proceed.
title: ''
labels: 'minor bug'
assignees: ''

---

## Steps to Reproduce (as best as you can)

## Expected Behavior

## Actual Behavior

## Crashlogs and Screenshots (if applicable)

_(you may drag + drop text logs and images here, thanks GitHub)_

## Other mods (if applicable)

### Discord username (if you want updates)

### Developer Notes (leave this blank)

_Difficulty_: **__**
_Estimated Time Required_: **__**
Once development starts.
