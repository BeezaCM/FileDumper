---
name: Feature/Improvement request
about: Suggest an enhancement
title: ''
labels: enhancement
assignees: ''

---

## Your Idea

### Discord username (if you want updates)

### Developer Notes (leave this blank)

_Difficulty_: **__**
_Estimated Time Required_: **__**
Once development starts.
