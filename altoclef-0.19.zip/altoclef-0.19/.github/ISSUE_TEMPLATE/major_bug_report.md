---
name: Major Bug report
about: Report a bug that permanently STOPS the bot from progressing/requires HUMAN input to continue
title: ''
labels: 'major bug'
assignees: ''

---

## Steps to Reproduce (as best as you can)

## Expected Behavior

## Actual Behavior (What lead to the bot getting permanently stuck)

## Crashlogs and Screenshots (if applicable)

_(you may drag + drop text logs and images here, thanks GitHub)_

## Other mods (if applicable)

### Discord username (if you want updates)

### Developer Notes (leave this blank)

_Difficulty_: **__**
_Estimated Time Required_: **__**
Once development starts.
